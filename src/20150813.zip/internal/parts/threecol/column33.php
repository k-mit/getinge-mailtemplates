<div style="display:inline-block; vertical-align:top; width:191px;" class="upperColumnWidth">
    <table align="<?=$tc3==1?"left":$tc3==2?"center":"right"?>" border="0" cellpadding="0" cellspacing="0" width="100%" class="threeColumnsContainer">
        <tr>
            <td valign="top" class="upperLeftColumnContainer">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnCaptionBlock">
                    <tbody class="mcnCaptionBlockOuter">
                    <tr>
                        <td class="mcnCaptionBlockInner" valign="top" style="padding:9px;">


                            <table align="<?=$tc3==1?"left":$tc3==2?"center":"right"?>" border="0" cellpadding="0" cellspacing="0"
                                   class="mcnCaptionBottomContent" width="false">
                                <tbody>
                                <tr>
                                    <td class="mcnCaptionBottomImageContent" align="<?=$tc3==1?"left":$tc3==2?"center":"right"?>" valign="top"
                                        style="padding:0 0 9px 0;">


                                        <img alt=""
                                             src="https://k-mit.se/dev/getinge/mail/strat.jpg"
                                             width="174" style="max-width:480px;" class="mcnImage">


                                    </td>
                                </tr>
                                <tr>
                                    <td class="mcnTextContent" valign="top" style="padding:0; text-align: left" width="174">
                                        <h2 >Lorem ipsum dolor sit amet, ferri consul laudem.</h2>

                                        <div style="color:#787878; font-size:12px; padding-top: 9px;font-style: italic; font-weight: bold;"class="blueSubheader">2015.06.02 | Exhibition</div>
                                        Experience how INSIGHT can improve workflow efficiency and the quality of
                                        patient care at your hospital. Come to booth no. S2G30 to learn more and
                                        exchange ideas at our bistro while you enjoy coffees and snacks.<br><br style="line-height: 30px;">
                                        <a class="readmoreButton" href="http://getingegroup.com" target="_blank" style="color: #0046ad; text-decoration: none; padding: 15px 20px; border: 1px solid #0046ad; font-weight: 200; text-align: center;">Read more</a><br><br>
                                    </td>
                                </tr>
                                </tbody>
                            </table>


                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </table>
</div>

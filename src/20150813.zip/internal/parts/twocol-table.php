<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="twocoltable">
    <tr>
        <td align="center" valign="top" style="padding: 9px 0 9px 18px;">
            <!-- BEGIN INDIVIDUAL COLUMNS // -->
            <!--[if gte mso 9]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" style="width:582px;" width="582">
                <tr>
                    <td align="center" valign="top" style="width:291px;" width="291">
            <![endif]-->
            <table align="left" border="0" cellpadding="0" cellspacing="0" width="291" style="width: 291px"
                   class="lowerColumnContainer">
                <tr>
                    <td valign="top" class="lowerRightColumnContainer">
                        <table border="0" cellpadding="0" cellspacing="0" style="width: 291px" width="291"
                               class="mcnCaptionBlock">
                            <tbody class="mcnCaptionBlockOuter">
                            <tr>
                                <td class="mcnCaptionBlockInner" valign="top" style="padding:0 0 0">
                                    <table align="left" border="0" cellpadding="0" cellspacing="0"
                                           class="mcnCaptionBottomContent" width="false">
                                        <tbody>
                                        <tr>
                                            <td class="mcnTextContent" valign="top" style="padding:0 0" width="273">
                                                <!-- BEGIN COLUMN CONTENT -->

                                                <table width="100%" cellpadding="9" class="hideableTable" style="font-family: 'Helvetica Neue', Helvetica, Arial;padding:9px;font-size: 13px;!important">
                                                    <thead class="eor">
                                                    <tr style="background-color: #e1eaf1;color:#0046ad">
                                                        <th>XYZ</th>
                                                        <th>ABC</th>
                                                        <th>DEF</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="eor eor-body">
                                                    <tr style="background-color: #ffffff;color:#000000;">
                                                        <td>No of emplyees</td>
                                                        <td>13089</td>
                                                        <td>13089</td>
                                                    </tr>
                                                    <tr style="background-color: #ededed;color:#000000;">
                                                        <td>No of sales companies</td>
                                                        <td>2945</td>
                                                        <td>2945</td>
                                                    </tr>
                                                    <tr style="background-color: #ffffff;color:#000000;">
                                                        <td>No of production facilities</td>
                                                        <td>22.5%</td>
                                                        <td>22.5%</td>
                                                    </tr>
                                                    <tr style="background-color: #ededed;color:#000000;">
                                                        <td>No of emplyees</td>
                                                        <td>13089</td>
                                                        <td>13089</td>
                                                    </tr>
                                                    <tr style="background-color: #ffffff;color:#000000;">
                                                        <td>No of sales companies</td>
                                                        <td>2945</td>
                                                        <td>2945</td>
                                                    </tr>
                                                    <tr style="background-color: #ededed;color:#000000;">
                                                        <td>No of production facilities</td>
                                                        <td>22.5%</td>
                                                        <td>22.5%</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                                <table width="100%" style="font-size: 0; max-height: 0; line-height: 0; display: none;" class="showableTable">
                                                    <tbody>
                                                    <tr>
                                                        <td style="">
                                                            <a style="" href="#">Click Here To Read The Stats</a>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                                <!-- END COLUMN CONTENT -->

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>

                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if gte mso 9]>
            </td>
            <td align="center" valign="top" style="width:300px;" width="300">
            <![endif]-->
            <table align="left" border="0" cellpadding="0" cellspacing="0" width="291" style="width: 291px"
                   class="lowerColumnContainer">
                <tr>
                    <td valign="top" class="lowerRightColumnContainer">
                        <table border="0" cellpadding="0" cellspacing="0" style="width: 291px" width="291"
                               class="mcnCaptionBlock">
                            <tbody class="mcnCaptionBlockOuter">
                            <tr>
                                <td class="mcnCaptionBlockInner" valign="top" style="padding:0 0 0">


                                    <table align="left" border="0" cellpadding="0" cellspacing="0"
                                           class="mcnCaptionBottomContent" width="false">
                                        <tbody>
                                        <tr>
                                            <td class="mcnTextContent" valign="top" style="padding:0 0" width="273">
                                                <!-- BEGIN COLUMN CONTENT -->
                                                <h2 style="margin-bottom: 10px;" class="null smallNegativeBottomSpace">Completely synergize
                                                    resource</h2>
                                                Efficiently unleash cross-media information
                                                without cross-media value. Quickly maximize
                                                timely deliverables for real-time schemas.
                                                Dramatically maintain clicks-and-mortar<br>
                                                solutions without functional solutions.<br>

                                                <!-- END COLUMN CONTENT -->
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if gte mso 9]>
            </td>
            </tr>
            </table>
            <![endif]-->
            <!-- // END INDIVIDUAL COLUMNS -->
        </td>
    </tr>
</table>

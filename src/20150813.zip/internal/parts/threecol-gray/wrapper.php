<td align="center" valign="top" id="threeColumnsGray">
    <table align="center" border="0" cellpadding="0" cellspacing="0"  width="100%">
        <tr>
            <td align="left" style="text-align:center; display:inline-block; padding-left: 9px" valign="top">
                <!-- BEGIN INDIVIDUAL COLUMNS // -->
                <!--[if gte mso 9]>
                <table align="left" border="0" cellspacing="0" cellpadding="0" style="width:573px;" width="573">
                    <tr>
                        <td align="left" valign="top" style="width:191px;" width="191">
                <![endif]-->
                <?php $tc3 = 1; include("column33.php"); ?>
                <!--[if gte mso 9]>
                </td>
                <td align="center" valign="top" style="width:191px;" width="191">
                <![endif]-->
                <?php $tc3 = 2; include("column33.php"); ?>
                <!--[if gte mso 9]>
                </td>
                <td align="right" valign="top" style="width:191px;" width="191">
                <![endif]-->
                <?php $tc3 = 3; include("column33.php"); ?>
                <!--[if gte mso 9]>
                </td>
                </tr>
                </table>
                <![endif]-->
                <!-- // END INDIVIDUAL COLUMNS -->
            </td>
        </tr>
    </table>
</td>
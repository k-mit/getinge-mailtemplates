<table align="left" border="0" cellpadding="0" cellspacing="0" width="291" style="width: 291px" class="lowerColumnContainer">
    <tr>
        <td valign="top" class="lowerRightColumnContainer"><table border="0" cellpadding="0" cellspacing="0" style="width: 291px"  width="291" class="mcnCaptionBlock">
                <tbody class="mcnCaptionBlockOuter">
                <tr>
                    <td class="mcnCaptionBlockInner" valign="top" style="padding:0 0 0">


                        <table align="left" border="0" cellpadding="0" cellspacing="0" class="mcnCaptionBottomContent" width="false">
                            <tbody><tr>
                                <td class="mcnCaptionBottomImageContent" align="left" valign="top" style="padding:0 0px 9px 0px;">



                                    <img alt="" src="https://k-mit.se/dev/getinge/mail/2part-img<?=$tccnt?>.png" width="273" style="max-width:460px;" class="mcnImage">


                                </td>
                            </tr>
                            <tr>
                                <td class="mcnTextContent" valign="top" style="padding:0 0" width="273">
                                    <h2>Lorem ipsum dolor sit amet, ferri consul laudem.</h2>

                                    <div style="font-style: italic; color:#787878; font-size:12px; padding-top: 9px;font-weight: bold;"class="blueSubheader">2015.06.02 | Exhibition</div>

                                    Experience how INSIGHT can improve workflow efficiency and the quality of patient care at your hospital.&nbsp;<br>
                                    <br>
                                    Come to booth no. S2G30 to learn more and exchange ideas at our bistro while you enjoy coffees and snacks.<br>
                                    <a class="readmoreLink" href="http://getingegroup.com" target="_blank" style="color:#0046ad; text-decoration: none;line-height: 40px;">Read more&nbsp;&rarr;</a>
                                </td>
                            </tr>
                            </tbody></table>
                    </td>
                </tr>
                </tbody>
            </table></td>
    </tr>
</table>

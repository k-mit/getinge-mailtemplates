<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td valign="top" class="preheaderContainer" style="padding: 18px;">

            <table align="left" border="0" cellpadding="0" cellspacing="0"
                   width="100%" class="mcnTextContentContainer">
                <tbody>
                <tr>

                    <td valign="top" class="mcnTextContent"
                        style="font-size: 10px; color: #d1d1d1">

                        We Welcome you to Arab Health 2015
                    </td>
                    <td valign="top" align="right" class="mcnTextContent"
                        style="text-align: right; font-size: 10px; color: #d1d1d1">

                        <a href="http://maquet.com" target="_blank">View this email in
                            your browser</a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr>
        <td valign="top" style="padding: 0 18px 18px 18px;">
            <table border="0" cellpadding="0" cellspacing="0" width="100%"
                   class="mcnTextBlock">
                <tbody class="mcnTextBlockOuter">
                <tr>

                    <td valign="middle" class="mcnTextContent" height="68"
                        style="padding: 0; height: 68px; border-top: 1px solid #d1d1d1;">

                        <table height="32" width="100%" style="height: 32px;">

                            <tbody>
                            <tr>
                                <td valign="middle"><img alt="Download Images"
                                                         src="https://k-mit.se/dev/getinge/mail/maquet-logo.png"
                                                         style="width: 95px; height: 32px; margin: 0px;"
                                                         width="95" height="32"></td>
                                <td valign="middle" align="right" class="headerTitle"
                                    style="text-align: right; font-family:arial,helvetica neue,helvetica,sans-serif;font-size:22px;line-height: 140%; color:#999999;">
                                    We Welcome you to Arab Health 2015
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                    <tr>
                    <td style="background-image: url('https://k-mit.se/dev/getinge/mail/dash_gray.png'); background-repeat: no-repeat; font-size: 4px; padding: 0">
                        <!--[if gte mso 9]>
                        <img src="https://k-mit.se/dev/getinge/mail/dash_gray.png" width="564" height="10">
                        <![endif]--><br>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
</table>

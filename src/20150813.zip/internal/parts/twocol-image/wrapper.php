<table border="0" cellpadding="0" cellspacing="0" width="100%" style=""
       class="mcnCaptionBlock">
    <tbody class="mcnCaptionBlockOuter">
    <tr>
        <td class="mcnCaptionBlockInner" valign="top" style="padding:0; background: #0045ad">


            <table border="0" cellpadding="0" cellspacing="0"
                   class="mcnCaptionRightContentOuter" width="100%">
                <tbody>
                <tr>
                    <td valign="top" class="mcnCaptionRightContentInner"
                        style="padding:0;">
                        <table align="right" border="0" cellpadding="0"
                               cellspacing="0"
                               class="mcnCaptionRightImageContentContainer">
                            <tbody>
                            <tr>
                                <td class="mcnCaptionRightImageContent"
                                    valign="top">


                                    <img alt=""
                                         src="https://k-mit.se/dev/getinge/mail/2-col-img.jpg"
                                         width="298" style=""
                                         class="mcnImage">


                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <table class="mcnCaptionLeftTextContentContainer"
                               align="left" border="0" cellpadding="0"
                               cellspacing="0" width="298">
                            <tbody>
                            <tr>
                                <td valign="top" class="mcnTextContent" style="color:#ffffff!important; padding: 18px 18px 18px 18px!important">
                                    <h2 style="color: #ffffff!important; font-size: 20px">Completely synergize
                                        resource</h2>
                                    <div style="color:#ffffff; font-weight: bold;  font-style: italic; font-size:12px; padding-top: 9px"class="blueSubheader">2015.06.02 | Solution</div>
                                     <span style="color:#ffffff; font-family: 'Helvetica Neue', Helvetica, Arial; font-size:15px;">Collaboratively administrate empowered
                                    markets via plug-and-play networks.
                                    Dynamically procrastinate B2C users after
                                    installed base benefits.</span><br>
                                    <a class="readmoreLink" href="http://getingegroup.com"
                                       target="_blank" style="color:#ffffff; text-decoration: none;line-height: 40px;">Read more &rarr;</a>

                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>


        </td>
    </tr>
    </tbody>
</table>

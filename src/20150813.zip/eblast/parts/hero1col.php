<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td align="center" valign="top" class="headerContainer">
            <table border="0" cellpadding="0" cellspacing="0" width="100%"
                   class="mcnImageBlock">
                <tbody class="mcnImageBlockOuter">
                <tr>
                    <td valign="top" style="padding:0px"
                        class="mcnImageBlockInner">
                        <table align="left" width="100%" border="0"
                               cellpadding="0"
                               cellspacing="0" class="mcnImageContentContainer">
                            <tbody>
                            <tr>
                                <td class="mcnImageContent" valign="top"
                                    style="padding-right: 0px; padding-left: 0px; padding-top: 0; padding-bottom: 0;">


                                    <img align="left" alt=""
                                         src="https://k-mit.se/dev/getinge/mail/topsplash.png"
                                         width="600"
                                         style="max-width:980px; padding-bottom: 0; display: inline !important; vertical-align: bottom;"
                                         class="mcnImage">


                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr>
        <td valign="top" class="mcnTextBlockInner">

            <table align="left" border="0" cellpadding="0" cellspacing="0"
                   width="600" class="mcnTextContentContainer">
                <tbody>
                <tr>
                    <td style="padding: 18px 18px 0 18px">
                        <h1>We Welcome you to Arab Health 2015</h1>

                    </td>
                </tr>
                <tr>

                    <td valign="top" class="mcnTextContent"
                        style="padding-top:9px; padding-right: 18px; padding-bottom: 9px; padding-left: 18px;">


                        <div style="color:#2ab2e5; font-size:12px;font-weight: bold;"class="blueSubheader">2015.06.02 | Exhibition</div>

                        For more than 175 years, Maquet has been a pioneer in
                        medical excellence for hospitals and clinicians. This
                        year, we will be&nbsp;presenting the latest in medical
                        technologies in conjunction with our partner companies
                        ArjoHuntleigh and Getinge Infection&nbsp;Control.<br>

                        <a class="readmoreLink" href="http://getingegroup.com" target="_blank" style="color:#0046ad; text-decoration: none;line-height: 40px;">
                            Read More &rarr;
                        </a>


                    </td>
                </tr>
                </tbody>
            </table>

        </td>
    </tr>
</table>
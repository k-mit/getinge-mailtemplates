<table border="0" cellpadding="0" cellspacing="0" width="100%"
       class="mcnCaptionBlock">
    <tbody class="mcnCaptionBlockOuter">
    <tr>
        <td class="mcnCaptionBlockInner" valign="top" style="padding:9px;">


            <table border="0" cellpadding="0" cellspacing="0"
                   class="mcnCaptionRightContentOuter" width="100%">
                <tbody>
                <tr>
                    <td valign="top" class="mcnCaptionRightContentInner"
                        style="padding:0 9px ;">
                        <table align="left" border="0" cellpadding="0"
                               cellspacing="0"
                               class="mcnCaptionRightImageContentContainer">
                            <tbody>
                            <tr>
                                <td class="mcnCaptionRightImageContent"
                                    valign="top">


                                    <img alt=""
                                         src="https://k-mit.se/dev/getinge/mail/2-col-img.jpg"
                                         width="273" style="max-width:459px;"
                                         class="mcnImage">


                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <table class="mcnCaptionRightTextContentContainer"
                               align="right" border="0" cellpadding="0"
                               cellspacing="0" width="273">
                            <tbody>
                            <tr>
                                <td valign="top" class="mcnTextContent">
                                    <h2 class="null">Completely synergize
                                        resource</h2>
                                    <div style="color:#2ab2e5; font-size:12px; padding-top: 9px;font-weight: bold;"class="blueSubheader">2015.06.02 | Solution</div>
                                    Collaboratively administrate empowered
                                    markets via plug-and-play networks.
                                    Dynamically procrastinate B2C users after
                                    installed base benefits.<br>
                                    <a class="readmoreLink" href="http://getingegroup.com"
                                       target="_blank" style="color:#0046ad; text-decoration: none;line-height: 40px;">Read more &rarr;</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>


        </td>
    </tr>
    </tbody>
</table>
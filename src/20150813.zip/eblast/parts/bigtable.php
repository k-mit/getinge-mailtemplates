<table border="0" cellpadding="0" cellspacing="0" width="100%"
       class="mcnBoxedTextBlock">
    <tbody class="mcnBoxedTextBlockOuter">
    <tr>
        <td valign="top" class="mcnBoxedTextBlockInner">

            <table align="left" border="0" cellpadding="0" cellspacing="0"
                   width="582" class="mcnBoxedTextContentContainer">
                <tbody>
                <tr>
                    <td valign="top" class="mcnTextContent" style="padding: 9px 0 9px 18px">
                        <table width="100%" border="0" cellpadding="9" class="hideableTable" style="border-color: #ffffff; font-family: 'Helvetica Neue', Helvetica, Arial;padding:9px;font-size: 13px;!important">
                            <thead class="eor">
                            <tr style="background-color: #cccccc;color:white;">
                                <th>XYZ</th>
                                <th>ABC</th>
                                <th>DEF</th>
                                <th>GHI</th>
                                <th>JKL</th>
                                <th>MNO</th>
                                <th>PQR</th>
                            </tr>
                            </thead>
                            <tbody class="eor eor-body">
                            <tr style="background-color: #ffffff;color:#000000;">
                                <td>No of emplyees</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                            </tr>
                            <tr style="background-color: #ededed;color:#000000;">
                                <td>No of sales companies</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                            </tr>
                            <tr style="background-color: #ffffff;color:#000000;">
                                <td>No of production facilities</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                            </tr>
                            <tr style="background-color: #ededed;color:#000000;">
                                <td>No of emplyees</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                                <td>13089</td>
                            </tr>
                            <tr class="background-color: #ffffff;color:#000000;">
                                <td>No of sales companies</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                                <td>2945</td>
                            </tr>
                            <tr style="background-color: #ededed;color:#000000;">
                                <td>No of production facilities</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                                <td>22.5%</td>
                            </tr>
                            </tbody>
                        </table>
                        <table width="100%" style="font-size: 0; max-height: 0; line-height: 0; display: none;" class="showableTable">
                            <tbody>
                            <tr>
                                <td style="">
                                    <a style="" href="#">Click Here To Read The Stats</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                    </td>
                </tr>
                </tbody>
            </table>

        </td>
    </tr>
    </tbody>
</table>

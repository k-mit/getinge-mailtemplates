<table width="100%" class="footerContainer">
    <tbody>
    <tr>
        <td style="padding: 9px 0 0 0">
            <table width="100%">
                <tr>
                    <td style="background-color:#0046ad; padding: 18px;color:#ffffff;font-size:11px;width:100%;" width="100%">
                        <table width="100%" style="width: 100%;" class="footerContainer">
                            <tr>
                                <td width="100%" style="border-top: 1px solid #ffffff;  padding: 18px 0">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="" class="footerContent">
                                        <tr>
                                            <td>
                                                <img
                                                    alt="Download Images"
                                                    src="https://k-mit.se/dev/getinge/mail/MAQUET-logo-gg_white1.gif"
                                                    width="100" height="38">

                                            </td>
                                            <td  align="right" valign="middle">
                                                <table>
                                                    <tr>
                                                        <td class="mcnTextContent" style="font-family: 'Helvetica Neue', Helvetica, Arial; line-height: 165%; color: #ffffff!important; text-align: right">
                                                            <a style="color: #ffffff; text-decoration: none" href="http://maquet.com">Contact us</a>&nbsp;&nbsp;<a style="color: #ffffff; text-decoration: none" href="http://maquet.com">About MAQUET</a>&nbsp;&nbsp;<a style="color: #ffffff; text-decoration: none" href="http://maquet.com">Terms of Use</a><br>
                                                            <span style="color:#ffffff;">&copy; 2015 MAQUET Holding B.V. &amp; Co. KG. All rights reserved</span>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                            <tr>
                                <td style="background-image: url('https://k-mit.se/dev/getinge/mail/dash_white.png'); background-repeat: no-repeat; font-size: 4px; padding: 0">
                                    <!--[if gte mso 9]>
                                    <img src="https://k-mit.se/dev/getinge/mail/dash_white.png" width="564" height="10">
                                    <![endif]--><br>
                                </td>
                            </tr>
                        </table>

                    </td>
                </tr>
            </table>
        </td>

    </tr>
    </tbody>
</table>

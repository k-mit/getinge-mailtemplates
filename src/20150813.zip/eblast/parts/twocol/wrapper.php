<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td align="center" valign="top" style="padding: 9px 0 9px 18px;">
            <!-- BEGIN INDIVIDUAL COLUMNS // -->
            <!--[if gte mso 9]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" style="width:582px;" width="582">
                <tr>
                    <td align="center" valign="top" style="width:291px;" width="291">
            <![endif]-->
            <?php $tccnt=1; include("column50.php"); ?>
            <!--[if gte mso 9]>
            </td>
            <td align="center" valign="top" style="width:291px;" width="291">
            <![endif]-->
            <?php $tccnt=2; include("column50.php"); ?>
            <!--[if gte mso 9]>
            </td>
            </tr>
            </table>
            <![endif]-->
            <!-- // END INDIVIDUAL COLUMNS -->
        </td>
    </tr>
</table>